#!/usr/bin/php
<html>
<head>

<title>Comparator Help</title>
<meta http-equiv="refresh" content="3; URL=http://dl.weberantoine.fr/help.php">
</head>
<body>
</body>
</html>