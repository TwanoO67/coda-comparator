#!/usr/bin/bash
nohup opendiff /tmp/CodaCompareFile_Left.tmp /tmp/CodaCompareFile_Right.tmp -merge /tmp/CodaCompareFile_Merge.tmp &